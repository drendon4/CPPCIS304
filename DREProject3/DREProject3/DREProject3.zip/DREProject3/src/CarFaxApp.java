
public class CarFaxApp {

    public static void main(String[] args) {
        CarFaxFrame inst = new CarFaxFrame();
        inst.setLocationRelativeTo(null);
        inst.setVisible(true);
    }
}
